ID:{{$genero->id_genero}}<br>
Designação:{{$genero->designacao}}<br>
Observações:{{$genero->observacoes}}
