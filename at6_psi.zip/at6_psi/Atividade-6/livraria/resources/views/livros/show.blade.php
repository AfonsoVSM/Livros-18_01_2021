ID:{{$livro->id_livro}}<br>
Titulo:{{$livro->titulo}}<br>
Idioma:{{$livro->idioma}}<br>
Data edicao:{{$livro->data_edicao}}<br>
Total paginas:{{$livro->total_paginas}}<br>
Isbn:{{$livro->isbn}}<br>
Observaçoes:{{$livro->observacoes}}<br>
Imagem capa:{{$livro->imagem_capa}}<br>
Genero:{{$livro->id_genero}}<br>
Autor:{{$livro->id_autor}}<br>
Sinopse:{{$livro->sinopse}}<br>
<a href="{{route('livros.edit', ['id'=>$livro->id_livro])}}">Editar</a>
<a href="{{route('livros.delete', ['id'=>$livro->id_livro])}}">Eliminar</a>


