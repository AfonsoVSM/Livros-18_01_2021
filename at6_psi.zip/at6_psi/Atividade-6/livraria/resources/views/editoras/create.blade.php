<form action="{{route('editoras.store')}}" method="post">
@csrf
Nome: <input type="text" name="nome"><br><br>
@if ($errors->has('nome'))<br><br>
Devera indicar um nome correto (4 carateres)
@endif
Morada: <input type="text" name="morada"><br><br>
@if ($errors->has('morada'))<br><br>
Devera indicar uma morada correta (13 carateres)
@endif
Observações: <input type="text" name="observacoes"><br><br>
@if ($errors->has('observacoes'))<br><br>
Devera indicar uma observaçao correta (4 carateres)
@endif


<input type="submit" value="Enviar">
</form>
