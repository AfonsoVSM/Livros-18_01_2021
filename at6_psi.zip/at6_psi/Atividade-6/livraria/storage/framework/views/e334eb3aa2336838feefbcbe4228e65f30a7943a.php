<ul>
<?php $__currentLoopData = $edicoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($edicao->id_editora); ?></li>
<li><?php echo e($edicao->id_livro); ?></li>
<li><?php echo e($edicao->data); ?></li>
<li><?php echo e($edicao->observacoes); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($edicoes->render()); ?><?php /**PATH D:\PSI\Atividade-4\livraria\resources\views/edicoes/index.blade.php ENDPATH**/ ?>