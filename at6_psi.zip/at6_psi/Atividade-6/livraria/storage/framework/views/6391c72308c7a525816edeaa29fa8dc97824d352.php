
<?php $__currentLoopData = $editoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
	<a href="<?php echo e(route('editoras.show',['id'
	=>$editora->id_editora])); ?>">
	<?php echo e($editora->nome); ?>

</a>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


<?php /**PATH D:\rafapsi_at-6\Atividade-6\livraria\resources\views/editoras/index.blade.php ENDPATH**/ ?>