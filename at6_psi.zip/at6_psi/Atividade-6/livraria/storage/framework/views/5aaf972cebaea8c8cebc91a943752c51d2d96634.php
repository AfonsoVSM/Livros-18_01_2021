ID:<?php echo e($livro->id_livro); ?><br>
Titulo:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?>

<?php if(isset($livro->genero->designacao)): ?>
<?php echo e($livro->genero->designacao); ?>

<?php endif; ?>
<?php if(isset($livro->autores->nome)): ?>
<?php echo e($livro->autores->nome); ?>

<?php endif; ?>
<?php $__currentLoopData = $livro->autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($autor->nome); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(count($livro->autores)>0): ?>
<?php $__currentLoopData = $livro->autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($autor->nome); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<div class="alert alert-danger" role='alert'>
	sem autor definido
</div>
<?php endif; ?>

<?php if(count($livro->editoras)>0): ?>
Editoras:
<?php $__currentLoopData = $livro->editoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($editora->nome); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<div class="alert alert-danger" role='alert'>
	sem editora definido
</div>
<?php endif; ?><?php /**PATH C:\Users\Utilizador\Desktop\Atividade-6\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>