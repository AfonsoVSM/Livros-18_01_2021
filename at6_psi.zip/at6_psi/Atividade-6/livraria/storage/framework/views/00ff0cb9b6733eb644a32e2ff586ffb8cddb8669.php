<form action="<?php echo e(route('editoras.store')); ?>" method="post">
<?php echo csrf_field(); ?>
Nome: <input type="text" name="nome"><br><br>
<?php if($errors->has('nome')): ?><br><br>
Devera indicar um nome correto (4 carateres)
<?php endif; ?>
Morada: <input type="text" name="morada"><br><br>
<?php if($errors->has('morada')): ?><br><br>
Devera indicar uma morada correta (13 carateres)
<?php endif; ?>
Observações: <input type="text" name="observacoes"><br><br>
<?php if($errors->has('observacoes')): ?><br><br>
Devera indicar uma observaçao correta (4 carateres)
<?php endif; ?>


<input type="submit" value="Enviar">
</form>
<?php /**PATH D:\rafapsi_at-6\Atividade-6\livraria\resources\views/editoras/create.blade.php ENDPATH**/ ?>