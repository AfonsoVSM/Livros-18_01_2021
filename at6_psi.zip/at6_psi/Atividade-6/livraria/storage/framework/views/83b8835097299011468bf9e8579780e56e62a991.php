ID:<?php echo e($genero->id_genero); ?><br>
Designação:<?php echo e($genero->designacao); ?><br>
Observações:<?php echo e($genero->observacoes); ?>

<?php /**PATH D:\at6_psi\Atividade-6\livraria\resources\views/generos/show.blade.php ENDPATH**/ ?>