ID:<?php echo e($autor->id_autor); ?><br>
Nome:<?php echo e($autor->nome); ?><br>
nacionalidade:<?php echo e($autor->nacionalidade); ?>

<?php /**PATH D:\rafapsi_at-6\Atividade-6\livraria\resources\views/autores/show.blade.php ENDPATH**/ ?>