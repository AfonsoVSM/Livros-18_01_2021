<ul>
<?php $__currentLoopData = $editoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($editora->nome); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($editoras->render()); ?><?php /**PATH D:\PSI\Atividade-2\livraria\resources\views/editoras/index.blade.php ENDPATH**/ ?>