<form action="<?php echo e(route('livros.store')); ?>" method="post">
<?php echo csrf_field(); ?>
Titulo: <input type="text" name="titulo"><br><br>
Idioma: <input type="text" name="idioma"><br><br>
Total paginas: <input type="text" name="total_paginas"><br><br>
Data Edição: <input type="text" name="data_edicao"><br><br>
ISBN: <input type="text" name="isbn" value="<?php echo e(old('isbn')); ?>"><br><br>
<?php if($errors->has('isbn')): ?><br><br>
Devera indicar um ISBN correto (13 carateres)
<?php endif; ?>
Observações: <textarea  name="observacoes"></textarea><br><br>
Imagem capa: <input type="text" name="imagem_capa"><br><br>
Genero:<input type="text" name="id_genero"><br><br>
Autor:<input type="text" name="id_autor"><br><br>
Sinopse:<textarea name="sinopse"><?php echo e(old('sinopse')); ?></textarea><br><br>
<input type="submit" value="Enviar">
</form><?php /**PATH D:\at6_psi\Atividade-6\livraria\resources\views/livros/create.blade.php ENDPATH**/ ?>